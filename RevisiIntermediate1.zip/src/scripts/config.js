export const ACCESS_TOKEN_KEY = 'accessToken';

export const BASE_URL = 'https://story-api.dicoding.dev/v1';
